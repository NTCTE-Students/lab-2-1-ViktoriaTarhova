<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($post->title); ?></title>
</head>
<body>
    <h1><?php echo e($post->title); ?></h1>
    <p><?php echo e($post->content); ?></p>
    <a href="<?php echo e(route('posts.index')); ?>">Back to list</a>
</body>
</html>
<?php /**PATH /root/.php-lerningphp-1/resources/views/posts/show.blade.php ENDPATH**/ ?>