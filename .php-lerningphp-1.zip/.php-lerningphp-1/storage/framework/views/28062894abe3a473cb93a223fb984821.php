<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Post</title>
</head>
<body>
    <h1>Edit Post</h1>
    <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?php echo e($post->title); ?>" required>
        <br>
        <label for="content">Content:</label>
        <textarea name="content" id="content" required><?php echo e($post->content); ?></textarea>
        <br>
        <button type="submit">Update</button>
    </form>
</body>
</html>

<?php /**PATH /root/.php-lerningphp-1/resources/views/posts/edit.blade.php ENDPATH**/ ?>